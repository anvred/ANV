package com.example.weatherapp;

import android.os.Bundle;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.weatherapp.adapters.AutoCompleteAdapter;
import com.example.weatherapp.adapters.RecyclerAdapter;
import com.example.weatherapp.adapters.RecyclerAdapterAccuWeather;
import com.example.weatherapp.interfaces.IWeatherCallbackListener;
import com.example.weatherapp.models.AccuWeather5DayModel;
import com.example.weatherapp.models.AccuWeatherModel;
import com.example.weatherapp.models.LocationSearchModel;
import com.example.weatherapp.models.OpenWeather5DayModel;
import com.example.weatherapp.models.OpenWeatherModel;
import com.example.weatherapp.utils.WeatherConditions;

import java.text.ParseException;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements IWeatherCallbackListener {

    @BindView(R.id.tv_city)
    TextView tvCity;
    @BindView(R.id.tv_country)
    TextView tvCountry;
    @BindView(R.id.btn_get_5_days_weather)
    Button btnGet5DaysWeather;
    @BindView(R.id.iv_weather_icon)
    ImageView ivWeatherIcon;
    @BindView(R.id.rv_weather_data)
    RecyclerView rvWeatherData;
    @BindView(R.id.et_city_name)
    AutoCompleteTextView etCityName;

    String OPEN_WEATHER_APP_ID = "b317aca2e83ad16e219ff2283ca837d5";
    String ACCU_WEATHER_APP_ID = "NyDBCwew8yG1EH9hbWuD5kmP7n3UKteK";

    LocationSearchModel mLocationSearchModel;
    @BindView(R.id.tv_info)
    TextView tvWeather;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        etCityName.setThreshold(2);
        etCityName.setAdapter(new AutoCompleteAdapter(MainActivity.this, ACCU_WEATHER_APP_ID));

        rvWeatherData.setLayoutManager(new LinearLayoutManager(this));

//        btnGetCurrentWeather.setOnClickListener(view -> WeatherConditions.getOpenWeatherData(etCityName.getText().toString(), OPEN_WEATHER_APP_ID, MainActivity.this));

        btnGet5DaysWeather.setOnClickListener(view -> WeatherConditions.getOpenWeatherData5Days(etCityName.getText().toString(), OPEN_WEATHER_APP_ID, MainActivity.this));

        etCityName.setOnItemClickListener((adapterView, view, i, l) -> {

            mLocationSearchModel = (LocationSearchModel) adapterView.getAdapter().getItem(i);

            etCityName.setText(mLocationSearchModel.getLocalizedName());

            WeatherConditions.getAccuWeatherData(mLocationSearchModel.getKey(), ACCU_WEATHER_APP_ID, MainActivity.this, true);

            WeatherConditions.getAccuWeatherData5Days(mLocationSearchModel.getKey(), ACCU_WEATHER_APP_ID, MainActivity.this, true);

        });

    }


    @Override
    public void getWeatherData(Object weatherModel, Boolean success, String errorMsg) {
        if (success) {
            if (weatherModel instanceof OpenWeatherModel) {

                OpenWeatherModel openWeatherModel = (OpenWeatherModel) weatherModel;
                tvCountry.setText("Country -- " + openWeatherModel.getSys().getCountry());
                tvCity.setText("City -- " + openWeatherModel.getName());
                tvWeather.setText("Temperature -- " + String.valueOf(openWeatherModel.getMain().getTemp()));
//                Glide.with(MainActivity.this)
//                        .load("http://openweathermap.org/img/w/" + openWeatherModel.getWeather().get(0).getIcon() + ".png")
//                        .into(ivWeatherIcon);

            } else if (weatherModel instanceof OpenWeather5DayModel) {

                OpenWeather5DayModel weatherBean = (OpenWeather5DayModel) weatherModel;
                try {
                    rvWeatherData.setAdapter(new RecyclerAdapter(MainActivity.this, weatherBean.getMinMaxTemp()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            } else if (weatherModel instanceof AccuWeatherModel) {

                AccuWeatherModel accuWeatherModel = (AccuWeatherModel) weatherModel;
                tvWeather.setText("Current Temperature : " + accuWeatherModel.getTemperature().getMetric().getValue() +"\u2103");
                tvCity.setText("City : " + mLocationSearchModel.getLocalizedName());
                tvCountry.setText("Country : " + mLocationSearchModel.getCountry().getLocalizedName());

                Glide.with(MainActivity.this)
                        .load("http://apidev.accuweather.com/developers/Media/Default/WeatherIcons/" + String.format("%02d", accuWeatherModel.getWeatherIcon()) + "-s" + ".png")
                        .into(ivWeatherIcon);

            } else if (weatherModel instanceof AccuWeather5DayModel) {

                AccuWeather5DayModel accuWeather5DayModel = (AccuWeather5DayModel) weatherModel;
                rvWeatherData.setAdapter(new RecyclerAdapterAccuWeather(MainActivity.this, accuWeather5DayModel));

            }
        }
    }
}
