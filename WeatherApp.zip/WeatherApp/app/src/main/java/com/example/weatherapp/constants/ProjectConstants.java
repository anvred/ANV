package com.example.weatherapp.constants;

/**
 */

public class ProjectConstants {
    public static final String BASE_URL_OPEN_WEATHER = "http://api.openweathermap.org/data/2.5/";
    public static final String BASE_DEV_URL_ACCU_WEATHER = "http://dataservice.accuweather.com/";
}
